//
//  SecondScreenViewController.swift
//  git practice
//
//  Created by Student on 4/4/20.
//  Copyright © 2020 Student. All rights reserved.
//

import UIKit

class PhysicalHealthViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning(){
        super.didReceiveMemoryWarning()
        
    }

}
